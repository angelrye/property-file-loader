# property-file-loader
Python code that loads a property file into a Class' dictionary attribute
